#include <vcl.h>
#pragma hdrstop

USERES("Test.res");
USEUNIT("T_Main.cpp");
USEUNIT("T_Thread.cpp");
USEASM("T_Asm.asm");
USEUNIT("T_Prog.cpp");
//---------------------------------------------------------------------------
#define WinMain

